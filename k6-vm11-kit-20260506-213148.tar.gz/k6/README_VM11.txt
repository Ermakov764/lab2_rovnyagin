Набор k6 для переноса на ВМ (vm11 и аналоги)
================================================

Состав архива
-------------
  cinema-constant.js      — сценарий нагрузки (LAB13: запись через kafka-proxy по умолчанию)
  run-ratio-sweep.sh      — три смеси POST/GET на каждый RESULT_CPU
  plot-from-results.sh    — вызов построения PNG
  plot_k6_cpu_results.py  — matplotlib: графики из results/cpu-*
  collect-observability-after-k6.sh — снимок observability после прогона
  env.sh                  — пример переменных (source перед запуском)
  requirements-plot.txt   — pip для графиков

Развёртывание на vm11 (замена каталога k6)
------------------------------------------
1. Сохрани со старой ВМ при необходимости копию:
     results/   png_k6/   reports/
2. Распакуй архив в домашний каталог (пример):
     mkdir -p ~/lab2_rovnyagin && cd ~/lab2_rovnyagin
     tar xzf k6-vm11-kit.tar.gz
   Либо только каталог k6 поверх существующего:
     tar xzf k6-vm11-kit.tar.gz -C ~
3. chmod +x k6/*.sh
4. Python для графиков (рекомендуется venv):
     python3 -m venv .venv && . .venv/bin/activate
     pip install -r k6/requirements-plot.txt

Зависимости на ВМ
-----------------
  • k6 — в PATH (https://k6.io/docs/getting-started/installation/)
  • python3 + matplotlib — для plot-from-results.sh (см. выше)
  • curl — для sweep/collect

LAB13 (запись в Kafka через прокси)
-----------------------------------
Подними kafka-proxy на этой же ВМ или доступный URL (порт по умолчанию 8082).

  export BASE_URL_KAFKA_PROXY=http://127.0.0.1:8082
  export K6_WRITE_MODE=kafka          # по умолчанию в cinema-constant.js
  # или снять прокси и бить в CRUD:  export K6_WRITE_MODE=rest

Можно добавить в начало сессии:
  source k6/env.sh

Типовой прогон с графиками
---------------------------
  source k6/env.sh
  export RESULT_CPU=0.5
  export AUTO_PLOT=1
  ./k6/run-ratio-sweep.sh

Полный раннер из корня репозитория (не входит в архив только k6):
  bash scripts/lab9-hl11-run-all.sh
  # задай K6_ROOT=$HOME/lab2_rovnyagin если каталог не ermakov_k6

Обновление архива на машине с репозиторием
-----------------------------------------
  bash scripts/package-k6-for-vm.sh
  → в корне появится k6-vm11-kit-YYYYMMDD-HHMMSS.tar.gz
